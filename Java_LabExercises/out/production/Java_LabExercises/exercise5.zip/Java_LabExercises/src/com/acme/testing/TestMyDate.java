package com.acme.testing;
import com.acme.utils.MyDate;


public class TestMyDate {

    public static void main(String[] args) {

        MyDate date1 = new MyDate(8,22,2000);

        MyDate date2 = new MyDate();
        date2.day = 14;
        date2.month = 7;
        date2.year = 2007;

        MyDate date3 = new MyDate();
        date3.setDate(5,1,2000);

        String str1 = date1.toString();
        String str2 = date2.toString();
        String str3 = date3.toString();
        System.out.println(str1);
        System.out.println(str2);
        System.out.println(str3);
    }
}
